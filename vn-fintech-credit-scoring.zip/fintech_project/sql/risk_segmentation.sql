-- =====================================================
-- Risk Segmentation Queries — Processed Parquet Table
-- Database: fintech_db | Table: processed_credit
-- =====================================================

-- Default rate theo DebtRatio Category (sau Glue ETL)
SELECT
    DebtRatio_Category,
    COUNT(*) AS customers,
    ROUND(AVG(CAST(SeriousDlqin2yrs AS DOUBLE)) * 100, 2) AS default_rate_pct
FROM fintech_db.processed_credit
GROUP BY DebtRatio_Category
ORDER BY default_rate_pct DESC;

-- Phân tích late payment history
SELECT
    CASE
        WHEN NumberOfTimes90DaysLate = 0 THEN 'Clean (0 lần)'
        WHEN NumberOfTimes90DaysLate = 1 THEN '1 lần'
        WHEN NumberOfTimes90DaysLate <= 3 THEN '2-3 lần'
        ELSE '4+ lần (chronic)'
    END AS late_90_bucket,
    COUNT(*) AS customers,
    ROUND(AVG(CAST(SeriousDlqin2yrs AS DOUBLE)) * 100, 2) AS default_rate_pct
FROM fintech_db.processed_credit
GROUP BY 1
ORDER BY default_rate_pct DESC;
