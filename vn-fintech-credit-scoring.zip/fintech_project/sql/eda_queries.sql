-- =====================================================
-- VN Fintech Credit Scoring — EDA SQL Queries
-- Database: fintech_db | Table: credit_data
-- Run on: AWS Athena
-- =====================================================

-- Query 1: Default rate phân theo nhóm tuổi
SELECT
    CASE
        WHEN age < 25 THEN 'Duoi 25'
        WHEN age < 35 THEN '25-35'
        WHEN age < 45 THEN '35-45'
        WHEN age < 55 THEN '45-55'
        ELSE 'Tren 55'
    END AS age_group,
    COUNT(*) AS total_customers,
    SUM(default_flag) AS total_defaults,
    ROUND(AVG(default_flag) * 100, 2) AS default_rate_pct
FROM fintech_db.credit_data
GROUP BY 1
ORDER BY default_rate_pct DESC;

-- Query 2: Risk segmentation theo thu nhập
SELECT
    CASE
        WHEN income < 3000 THEN 'Thap (<3k)'
        WHEN income < 6000 THEN 'Trung binh (3-6k)'
        WHEN income < 10000 THEN 'Kha (6-10k)'
        ELSE 'Cao (>10k)'
    END AS income_segment,
    COUNT(*) AS total_customers,
    ROUND(AVG(default_flag) * 100, 2) AS default_rate_pct,
    ROUND(AVG(debt_ratio), 3) AS avg_debt_ratio
FROM fintech_db.credit_data
WHERE income IS NOT NULL
GROUP BY 1
ORDER BY default_rate_pct DESC;

-- Query 3: Cross-segment risk ranking với Window Function
SELECT
    age_group,
    income_segment,
    default_rate_pct,
    RANK() OVER (ORDER BY default_rate_pct DESC) AS risk_rank
FROM (
    SELECT
        CASE WHEN age < 35 THEN 'Young (<35)' ELSE 'Senior (35+)' END AS age_group,
        CASE WHEN income < 5000 THEN 'Low income (<5k)' ELSE 'High income (5k+)' END AS income_segment,
        ROUND(AVG(default_flag) * 100, 2) AS default_rate_pct
    FROM fintech_db.credit_data
    WHERE income IS NOT NULL
    GROUP BY 1, 2
) sub
ORDER BY risk_rank;
