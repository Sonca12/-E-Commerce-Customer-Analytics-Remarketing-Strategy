import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

# Đọc từ Data Catalog
datasource = glueContext.create_dynamic_frame.from_catalog(
    database = "fintech_db",
    table_name = "credit_training"
)
df = datasource.toDF()

# Xử lý missing values
df = df.fillna({
    'MonthlyIncome': df.approxQuantile('MonthlyIncome', [0.5], 0.01)[0],
    'NumberOfDependents': 0
})

# Tạo feature mới
df = df.withColumn('DebtRatio_Category',
    F.when(F.col('DebtRatio') < 0.3, 'Low')
     .when(F.col('DebtRatio') < 0.6, 'Medium')
     .otherwise('High'))

# Lưu dưới dạng Parquet
df.write.mode('overwrite').parquet(
    's3://vn-fintech-credit-bachquangtung/processed/'
)
job.commit()